"use client";
import axios from "axios";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { ChevronUpIcon } from "@radix-ui/react-icons"
import { Input } from "@/components/ui/input";
import { zodResolver } from "@hookform/resolvers/zod";
import { useSearchParams } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { ResponseInterface } from "./response-interface";
import * as z from "zod";


const formSchema = z.object({
  question: z.string(),
})

type ChatFormValue = z.infer<typeof formSchema>;

export default function ChatForm() {
  const [responseList, setResponseList] = useState<ResponseInterface[]>([]);
  const [prompt, setPrompt] = useState<string>('');
  const [promptToRetry, setPromptToRetry] = useState<string | null>(null);
  const [uniqueIdToRetry, setUniqueIdToRetry] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [reportCreated, setReportCreated] = useState(false);
  const [reportConfig, setReportConfig] = useState(null);
  let loadInterval: number | undefined;

  const searchParams = useSearchParams();
  const callbackUrl = searchParams.get("callbackUrl");
  const [loading, setLoading] = useState(false);
  const form = useForm<ChatFormValue>({
    resolver: zodResolver(formSchema),
  });

  const generateUniqueId = () => {
    const timestamp = Date.now();
    const randomNumber = Math.random();
    const hexadecimalString = randomNumber.toString(16);

    return `id-${timestamp}-${hexadecimalString}`;
  }

  const htmlToText = (html: string) => {
    const temp = document.createElement('div');
    temp.innerHTML = html;
    return temp.textContent;
  }

  const delay = (ms: number) => {
    return new Promise( resolve => setTimeout(resolve, ms) );
  }

  const addLoader = (uid: string) => {
    const element = document.getElementById(uid) as HTMLElement;
    element.textContent = ''

    // @ts-ignore
    loadInterval = setInterval(() => {
      // Update the text content of the loading indicator
      element.textContent += '.';

      // If the loading indicator has reached three dots, reset it
      if (element.textContent === '....') {
        element.textContent = '';
      }
    }, 300);
  }

  const addResponse = (selfFlag: boolean, response?: string) => {
    const uid = generateUniqueId()
    setResponseList(prevResponses => [
      ...prevResponses,
      {
        id: uid,
        response,
        selfFlag
      },
    ]);
    return uid;
  }

  const updateResponse = (uid: string, updatedObject: Record<string, unknown>) => {
    setResponseList(prevResponses => {
      const updatedList = [...prevResponses]
      const index = prevResponses.findIndex((response) => response.id === uid);
      if (index > -1) {
        updatedList[index] = {
          ...updatedList[index],
          ...updatedObject
        }
      }
      return updatedList;
    });
  }

  const onSubmit = async (values: z.infer<typeof formSchema>, _uniqueIdToRetry?: string | null) =>{
    const { question } = values;

    // Get the prompt input
    const _prompt = question ?? htmlToText(prompt);
    console.log(_prompt);

    // If a response is already being generated or the prompt is empty, return
    if (isLoading || !_prompt) {
      return;
    }

    setIsLoading(true);

    // Clear the prompt input
    setPrompt('');

    let uniqueId: string;
    if (_uniqueIdToRetry) {
      uniqueId = _uniqueIdToRetry;
    } else {
      // Add the self prompt to the response list
      addResponse(true, _prompt);
      uniqueId = addResponse(false);
      await delay(50);
      addLoader(uniqueId);
    }

    try {
      // Send a POST request to the API with the prompt in the request body
      const response = await axios.post('/api/chatv2', {
        prompt: _prompt,
      });

      console.log('response', response);
      console.log(response.data);
      updateResponse(uniqueId, {
        response: response.data.message.trim(),
      });

      setPromptToRetry(null);
      setUniqueIdToRetry(null);

      // Check if the response contains report information
      if (response.data.message.indexOf("I have created a report for you") > -1) {

        // Assuming response.data.report contains embedUrl and embedReportId
        setReportConfig(response.data);
        setReportCreated(true);
      }

    } catch (err) {
      setPromptToRetry(_prompt);
      setUniqueIdToRetry(uniqueId);
      updateResponse(uniqueId, {
        // @ts-ignore
        response: `Error: ${err.message}`,
        error: true
      });
    } finally {
      // Clear the loader interval
      clearInterval(loadInterval);
      setIsLoading(false);
    }
  }

  // const onSubmit = async (data: ChatFormValue) => {
  //   console.log(data);
  // };

  return (
    <>
      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className="space-y-2 w-full"
        >
          <FormField
            control={form.control}
            name="question"
            render={({ field }) => (
              <FormItem>
                <div className="flex items-center space-x-2"> 
                  <FormControl>
                    <Input
                      type="question"
                        placeholder="Ask your data..."
                        disabled={loading}
                        className="flex-grow"

                        {...field}
                      />
                  </FormControl>
                  <Button variant="outline" size="icon" type="submit">
                    <ChevronUpIcon className="h-4 w-4" />
                  </Button>
                </div>
                <FormMessage /> {/* This will now be outside the FormItem */}
              </FormItem>
            )}
          />
        </form>
      </Form>

    </>
  );
}
