export interface ResponseInterface {
  id: string;
  response?: string;
  selfFlag: boolean;
  error?: boolean;
  image?: string;
}
